from twilio.rest import Client

# Your Twilio Account SID and Auth Token
account_sid = 'AC0a70274ca85dd609d1ae294c6c66d405'
auth_token = 'd47e11db3ab9de1f9686d63bf8610f9a'

# Create a Twilio client
client = Client(account_sid, auth_token)

# Recipient's phone number (in E.164 format, e.g., +1234567890)
to_phone_number = '+918871310554'

# Generate a random 6-digit OTP
import random
otp = ''.join(str(random.randint(0, 9)) for _ in range(6))

# Compose the SMS message
sms_message = f"Your OTP code is: {otp}"

# Send the SMS
message = client.messages.create(
    to=to_phone_number,
    from_='+12295365750',  # Replace with your Twilio phone number
    body=sms_message
)

print("OTP sent successfully.")
