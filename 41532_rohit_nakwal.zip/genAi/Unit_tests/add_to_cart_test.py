import unittest
from app import add_to_cart

class TestAddToCart(unittest.TestCase):

  def test_add_to_cart(self):
    # Mock product data
    product_id = '1'
    product_name = 'Test Product'
    product_price = '9.99'

    # Call function
    add_to_cart(product_id, product_name, product_price)

    # Assert product added to cart
    self.assertIn({'id': product_id, 'name': product_name, 'price': product_price}, session['cart'])

  def test_new_cart(self):
    # Clear cart
    session.pop('cart', None)

    # Mock product data and call function
    product_id = '1'
    product_name = 'Test Product' 
    product_price = '9.99'
    add_to_cart(product_id, product_name, product_price)

    # Assert new cart created
    self.assertEqual(len(session['cart']), 1)
    self.assertIn({'id': product_id, 'name': product_name, 'price': product_price}, session['cart'])
