import unittest
from app import generate_otp

class TestGenerateOtp(unittest.TestCase):

  def test_generate_otp(self):
    otp = generate_otp()
    self.assertEqual(len(otp), 6)
    self.assertIsInstance(otp, str)
