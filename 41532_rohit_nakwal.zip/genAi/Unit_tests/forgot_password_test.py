import unittest
from app import send_forgot_password_otp, phone_number_exists

class TestSendForgotPasswordOtp(unittest.TestCase):

  def test_registered_phone(self):
    # Mock phone number exists
    phone = '1234567890'
    phone_number_exists.return_value = True

    # Call function 
    response = send_forgot_password_otp(phone)

    # Assert correct template rendered
    self.assertEqual(response, render_template("/verify_forgot_otp.html", phone=phone))

  def test_unregistered_phone(self):
    # Mock phone number does not exist
    phone = '0987654321'
    phone_number_exists.return_value = False

    # Call function
    response = send_forgot_password_otp(phone)

    # Assert error message returned
    self.assertEqual(response, "Phone number not found. Please check the registered mobile number.")
