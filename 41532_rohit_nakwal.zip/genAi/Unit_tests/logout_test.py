import unittest
from app import logout

class TestLogout(unittest.TestCase):

  def test_logout(self):
    # Mock logged in user session
    session['user_id'] = '1'  

    # Call logout function
    response = logout()

    # Assert session cleared
    self.assertEqual(session, {})

    # Assert redirect to login
    self.assertEqual(response.status_code, 302)
    self.assertEqual(response.location, url_for('login_step1'))
