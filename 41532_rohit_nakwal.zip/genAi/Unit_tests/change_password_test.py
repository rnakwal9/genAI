import unittest
from app import change_password

class TestChangePassword(unittest.TestCase):

  def test_change_password_success(self):
    # Mock current password match, new password match
    current_password = 'current123' 
    new_password = 'new456'
    confirm_password = 'new456'

    # Call function
    response = change_password(current_password, new_password, confirm_password)

    # Assert successful password change response
    self.assertEqual(response, "Password updated successfully. Please click <a href='" + url_for('product') + "'>here</a> to log in.")

  def test_change_password_current_incorrect(self):
    # Mock incorrect current password
    current_password = 'wrong123'
    new_password = 'new456'
    confirm_password = 'new456'

    # Call function 
    response = change_password(current_password, new_password, confirm_password)

    # Assert current password error
    self.assertEqual(response, 'Current password is incorrect')

  def test_change_password_mismatch(self):
    # Mock new password mismatch
    current_password = 'current123'
    new_password = 'new456' 
    confirm_password = 'mismatch'

    # Call function
    response = change_password(current_password, new_password, confirm_password)

    # Assert password mismatch error 
    self.assertEqual(response, 'New password and confirm password do not match')
