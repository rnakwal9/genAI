import unittest
from app import verify_otp_route

class TestVerifyOtpRoute(unittest.TestCase):

  def test_verify_otp_valid(self):
    # Mock phone, otp mapping, and OTP
    phone = '1234567890' 
    otp = '123456'
    phone_otp_mapping[phone] = {'otp': otp}

    # Call route with valid OTP
    response = verify_otp_route(phone, otp)

    # Assert redirect to /product
    self.assertEqual(response.status_code, 302) 
    self.assertEqual(response.location, '/product')

  def test_verify_otp_invalid(self):
     # Mock phone and incorrect OTP
     phone = '1234567890'
     otp = '654321' 

     # Call route with invalid OTP
     response = verify_otp_route(phone, otp)

     # Assert error message
     self.assertEqual(response, "Invalid OTP. Please try again.")
