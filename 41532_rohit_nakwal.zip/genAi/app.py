import sqlite3
"""
Imports modules for building a Flask web application with user authentication, 
database integration, logging, and payment processing.

Sets up a Flask app instance, Flask session for user login state, 
SQLite databases for users and products, and logging.

Implements user registration, login, logout, password reset flows with OTP verification. 

Adds product catalog and shopping cart functionality.

Includes payment integration with Stripe.

Provides common web app patterns like input validation, database queries, 
templating, flash messages, etc.
"""

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import random
import string
from twilio.rest import Client
from flask import Flask, session
from flask_session import Session
import logging
import stripe
app = Flask(__name__)

# Configure Flask-Session to use a server-side session storage.
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)
logging.basicConfig(filename='app.log', level=logging.INFO)
# Add this function to generate a random 6-digit OTP
def generate_otp():
    return ''.join(random.choice(string.digits) for _ in range(6))

# Define dictionaries to store the data
username_data = {}  # To store the username
phone_otp_mapping = {}  # To store the phone number and OTP
registered_users = {} 

# Add a function to send an email with OTP
def send_otp_email(number, otp):
    # Your Twilio Account SID and Auth Token
    account_sid = 'AC0a70274ca85dd609d1ae294c6c66d405'
    auth_token = 'd47e11db3ab9de1f9686d63bf8610f9a'

    # Create a Twilio client
    client = Client(account_sid, auth_token)
    # Compose the SMS message
    sms_message = f"Your OTP code for login into your e-commerce account is: {otp}"
    # Send the SMS
    message = client.messages.create(
        to=number,
        from_='+12295365750',  # Replace with your Twilio phone number
        body=sms_message
    )
    

@app.route('/login_step1', methods=['GET'])
def login_step1():
    return render_template('login_step1.html')

@app.route('/login_step2', methods=['POST'])
def login_step2():
    email = request.form['email']
    password = request.form['password']

    # Check if the email and password match
    cursor = get_db().cursor()
    cursor.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password))
    user = cursor.fetchone()

    if not user:
        return "Email or password is incorrect. Please try again."

    username_data[email] = True
    return render_template('login_step2.html')

@app.route('/send_otp', methods=['POST'])
def send_otp_route():
    phone = request.form.get('phone')

    otp = generate_otp()  # Implement a function to generate OTPs
    phone_otp_mapping[phone] = {'otp': otp} # Store the OTP with the phone number
    send_otp_email(phone, otp)  # Implement a function to send OTPs to users
    return render_template("/verify_otp.html", phone=phone)


# The verification route is called after the user submits the OTP.
@app.route('/verify_otp', methods=['POST'])
def verify_otp_route():
    phone = request.form.get('phone')
    user_entered_otp = request.form.get('otp')
     # Check if the phone number exists in the dictionary
    if phone in phone_otp_mapping:
        stored_otp = phone_otp_mapping[phone]['otp']
        if user_entered_otp == stored_otp:
            # OTP is correct; you can access the username using the username_data dictionary
            username = [username for username, _ in username_data.items() if username_data[username]]
            session['username'] = username[0]
            return redirect("/product")
    else:
        # OTP is incorrect; you can handle this as needed
        return "Invalid OTP. Please try again."



# Forgot Password page
@app.route('/forgot_password', methods=['GET'])
def forgot_password_page():
    return render_template('forgot_password.html')


def phone_number_exists(phone):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE phone = ?', (phone,))
    result = cursor.fetchone()

    conn.close()

    return result is not None


@app.route('/forgot_password', methods=['POST'])
def send_forgot_password_otp():
    phone = request.form.get('phone')
    
    # Check if the phone number is registered
    if phone_number_exists(phone):
        # Generate a new OTP and store it
        session['phone'] = phone
        otp = generate_otp()  # Implement a function to generate OTPs
        phone_otp_mapping[phone] = {'otp': otp}
        send_otp_email(phone, otp)  # Implement a function to send OTPs to users
        return render_template("/verify_forgot_otp.html", phone=phone)
    
    return "Phone number not found. Please check the registered mobile number."

# The verification route is called after the user submits the OTP.
@app.route('/verify_forgot_otp', methods=['POST'])
def verify_forgot_otp_route():
    phone = request.form.get('phone')
    user_entered_otp = request.form.get('otp')
     # Check if the phone number exists in the dictionary
    if phone in phone_otp_mapping:
        stored_otp = phone_otp_mapping[phone]['otp']
        if user_entered_otp == stored_otp:
            # OTP is correct; you can access the username using the username_data dictionary
            return render_template("reset_password.html", phone=phone)
    else:
        # OTP is incorrect; you can handle this as needed
        return "Invalid OTP. Please try again."

@app.route('/reset_password', methods=['POST'])
def reset_password():
    return render_template("reset_password.html")


@app.route('/update_password', methods=['POST'])
def reset_password_route():
    phone = session['phone']
    password = request.form.get('new_password')
    
    # Update the password in the database
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    cursor.execute('UPDATE users SET password = ? WHERE phone = ?', (password, phone))
    conn.commit()
    session.pop(phone,None)
    conn.close()

    return "Password updated successfully. Please click <a href='" + url_for('login_step1') + "'>here</a> to log in."

@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirect to login if the user is not authenticated

    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        username = session['username']
        app.logger.info("Username for change password: {} ".format(username))
        # Connect to the database and execute a query to fetch the old password
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()

        # Replace 'users' with the actual table name in your database
        cursor.execute("SELECT password FROM users WHERE email = ?", (username,))
        result = cursor.fetchone()
        app.logger.info("Old password: {}".format(result[0]))
        if result and result[0] == current_password:
            app.logger.info("Old password matches")
            if new_password == confirm_password:
                # Update the user's password in the database
                cursor.execute("UPDATE users SET password = ? WHERE email = ?", (new_password, username))
                conn.commit()
                flash('Password changed successfully', 'success')
                return"Password updated successfully. Please click <a href='" + url_for('product') + "'>here</a> to log in."
            else:
                return 'New password and confirm password do not match'
        else:
             return 'Current password is incorrect'

        conn.close()
    return render_template('change_password.html')

@app.route('/product')
def product_page():
    # Connect to the database
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()

    # Fetch product details from the database
    cursor.execute('SELECT id, name, description, price FROM products')
    products = cursor.fetchall()

    # Close the database connection
    conn.close()

    return render_template('product.html', products=products, username=session['username'])

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    product_id = request.form.get('product_id')
    product_name = request.form.get('product_name')
    product_price = request.form.get('product_price')

    if 'cart' not in session:
        session['cart'] = []

    session['cart'].append({
        'id': product_id,
        'name': product_name,
        'price': product_price
    })

    flash(f'{product_name} added to the cart', 'success')
    return redirect(url_for('product_page'))

@app.route('/view_cart')
def view_cart():
    if 'cart' not in session:
        session['cart'] = []

    cart = session['cart']

    # You can retrieve product information from your database or another data source based on the items in the cart.
    app.logger.info(cart)
    app.logger.info(session['cart'])
    total = sum(float(item['price']) for item in cart)
    return render_template('view_cart.html', cart=cart, total=total)

@app.route('/checkout')
def checkout():
    if 'cart' not in session:
        session['cart'] = []

    cart = session['cart']
    total = sum(float(item['price']) for item in cart)

    return render_template('checkout.html', total=total)


@app.route('/process_payment', methods=['POST'])
def process_payment():
    # Retrieve user information and payment details from the form
    name = request.form['name']
    # Extract more form fields as needed

    # Process payment (integrate with a payment gateway)

    # Clear the cart after a successful payment
    session.pop('cart', None)

    flash('Payment successful. Thank you!', 'success')

    # Redirect to a success page or another appropriate route
    return redirect(url_for('get_payment_page'))


@app.route('/payment', methods=['GET'])
def get_payment_page():
    return render_template('payment.html')

@app.route('/payment', methods=['POST'])
def proc_payment():
    # Get the token from the client-side (e.g., using Stripe.js)
    token = request.form['stripeToken']

    try:
        # Create a charge using the token and the amount to charge (in cents)
        charge = stripe.Charge.create(
            amount=1000,  # Amount in cents
            currency="usd",
            source=token,
            description="Example Charge"
        )

        # The payment was successful
        return jsonify(status="success", message="Payment successful")

    except stripe.error.CardError as e:
        # The card was declined
        return jsonify(status="error", message=str(e))

@app.route('/logout')
def logout():
    # Clear the user's session to log them out
    session.clear()  # Assuming you are using Flask's session

    # You can also perform other logout-related tasks, like revoking tokens if you use OAuth.

    # Redirect the user to a different page (e.g., the login page) after logging out
    return redirect(url_for('login_step1')) 


# Function to create a new database connection
def get_db():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

# Create the users table if it doesn't exist
def init_db():
    conn = get_db()
    with app.open_resource('schema.sql', mode='r') as f:
        conn.cursor().executescript(f.read())
    conn.commit()
    conn.close()

# Initialize the database
init_db()

def init_product_db():
    conn = sqlite3.connect('products.db')

    # Create a cursor object to execute SQL commands
    cursor = conn.cursor()

    # Define a table to store product details
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            price REAL
        )
    ''')

    # Commit changes and close the database connection
    conn.commit()
    conn.close()

def insert_product():
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()

    # Insert product data
    cursor.execute('INSERT INTO products (name, description, price) VALUES (?, ?, ?)', ('iPhone 15 Plus', 'Description of iPhone 15 Plus', 19.99))
    cursor.execute('INSERT INTO products (name, description, price) VALUES (?, ?, ?)', ('iPhone 15 Pro Max', 'Description of iPhone 15 Pro Max', 29.99))

    # Commit changes and close the database connection
    conn.commit()
    conn.close()

# init_product_db()
# insert_product()
 
@app.route('/')
def registration():
    return render_template('registration.html')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    email = request.form['email']
    phone = request.form['phone']
    password = request.form['password']

    # Basic validation (add more checks as needed)
    if not username or not email or not password:
        return "All fields are required."

    # Check if the user already exists
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    existing_user = cursor.fetchone()

    if existing_user:
        cursor.close()
        conn.close()
        return "Username already exists."
    
    if phone in registered_users:
        return "Phone number is already registered."
    
    # Register the user (store the username and phone)
    registered_users[phone] = {'username': username}
    # Insert the user data into the database
    cursor.execute('INSERT INTO users (username, email, phone, password) VALUES (?, ?, ?, ?)', (username, email, phone, password))
    conn.commit()
    
    cursor.close()
    conn.close()

    return redirect('/login_step1')

@app.route('/reset_session')
def reset_session():
    session.clear()  # Reset the session by assigning an empty dictionary to it
    return "Session has been reset."

if __name__ == '__main__':
    app.run(debug=True)
